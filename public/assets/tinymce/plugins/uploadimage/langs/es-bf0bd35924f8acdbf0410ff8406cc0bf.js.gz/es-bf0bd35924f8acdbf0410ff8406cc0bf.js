tinyMCE.addI18n('es', {
  'Insert an image from your computer': 'Insertar una imagen desde su computadora',
  'Insert image': 'Insertar una imagen',
  'Choose an image': "Elija una imagen",
  'You must choose a file': "Debe elegir un archivo",
  'Got a bad response from the server': "Mala respuesta del servidor",
  "Didn't get a response from the server": "No se recibió respuesta del servidor",
  'Insert': "Insertar",
  'Cancel': "Cancelar",
  'Image description': "Descripción de la imagen",
});
